import hashlib
import json
from dataclasses import asdict
from typing import Any

from bom_core.models.bom_state import BomState
from bom_core.models.snapshot import BomSnapshot

SCHEMA_VERSION = 1


def create_snapshot(state: BomState) -> BomSnapshot:
    """
    Canonical snapshot:
    - deterministic sort order
    - deterministic JSON encoding
    - stable hash for future comparisons
    """
    payload = _canonical_payload(state)
    payload_json = json.dumps(payload, separators=(",", ":"), sort_keys=True)
    content_hash = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
    return BomSnapshot(
        schema_version=SCHEMA_VERSION,
        content_hash=content_hash,
        payload_json=payload_json,
    )


def compare_snapshots(old: BomSnapshot, new: BomSnapshot) -> dict[str, Any]:
    if old.schema_version != new.schema_version:
        raise ValueError("Snapshot schema versions differ")

    old_payload = json.loads(old.payload_json)
    new_payload = json.loads(new.payload_json)

    old_parts = {p["part_id"]: p for p in old_payload["parts"]}
    new_parts = {p["part_id"]: p for p in new_payload["parts"]}

    old_rels = {_rel_key(r): r for r in old_payload["relationships"]}
    new_rels = {_rel_key(r): r for r in new_payload["relationships"]}

    added_parts = sorted(set(new_parts) - set(old_parts))
    removed_parts = sorted(set(old_parts) - set(new_parts))
    changed_parts = sorted(
        part_id
        for part_id in (set(old_parts) & set(new_parts))
        if old_parts[part_id] != new_parts[part_id]
    )

    added_relationships = sorted(set(new_rels) - set(old_rels))
    removed_relationships = sorted(set(old_rels) - set(new_rels))
    changed_relationships = sorted(
        rel_key
        for rel_key in (set(old_rels) & set(new_rels))
        if old_rels[rel_key] != new_rels[rel_key]
    )

    return {
        "old_hash": old.content_hash,
        "new_hash": new.content_hash,
        "changed": old.content_hash != new.content_hash,
        "added_parts": added_parts,
        "removed_parts": removed_parts,
        "changed_parts": changed_parts,
        "added_relationships": added_relationships,
        "removed_relationships": removed_relationships,
        "changed_relationships": changed_relationships,
    }


def _rel_key(rel: dict[str, Any]) -> str:
    return f"{rel['parent_part_id']}->{rel['child_part_id']}"


def _canonical_payload(state: BomState) -> dict[str, Any]:
    parts = []
    for part in state.parts.values():
        part_dict = asdict(part)
        part_dict["weight_kg"] = float(part_dict["weight_kg"])
        parts.append(part_dict)
    parts.sort(key=lambda p: p["part_id"])

    relationships = []
    for rel in state.relationships:
        rel_dict = asdict(rel)
        rel_dict["quantity"] = float(rel_dict["quantity"])
        relationships.append(rel_dict)
    relationships.sort(
        key=lambda r: (r["parent_part_id"], r["child_part_id"], r["quantity"])
    )

    return {
        "schema_version": SCHEMA_VERSION,
        "root_part_id": state.root_part_id,
        "parts": parts,
        "relationships": relationships,
    }
