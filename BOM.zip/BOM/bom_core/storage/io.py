import csv
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Union

from bom_core.models.bom_state import BomState
from bom_core.models.part import Part
from bom_core.models.relationship import BomRelationship


def state_to_dict(state: BomState) -> dict[str, Any]:
    parts = [asdict(part) for part in state.parts.values()]
    parts.sort(key=lambda p: p["part_id"])

    relationships = [asdict(rel) for rel in state.relationships]
    relationships.sort(
        key=lambda r: (r["parent_part_id"], r["child_part_id"], r["quantity"])
    )

    return {
        "root_part_id": state.root_part_id,
        "parts": parts,
        "relationships": relationships,
    }


def state_from_dict(payload: dict[str, Any]) -> BomState:
    parts = {}
    for part_data in payload.get("parts", []):
        part = Part(
            part_id=part_data["part_id"],
            name=part_data["name"],
            weight_kg=float(part_data.get("weight_kg", 0.0)),
            unit_of_measure=part_data.get("unit_of_measure", "ea"),
            attributes=part_data.get("attributes", {}),
        )
        parts[part.part_id] = part

    relationships = []
    for rel_data in payload.get("relationships", []):
        relationships.append(
            BomRelationship(
                parent_part_id=rel_data["parent_part_id"],
                child_part_id=rel_data["child_part_id"],
                quantity=float(rel_data["quantity"]),
            )
        )

    return BomState(
        parts=parts,
        relationships=relationships,
        root_part_id=payload.get("root_part_id"),
    )


def export_state_json(state: BomState, path: Union[str, Path]) -> Path:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(state_to_dict(state), indent=2, sort_keys=True), encoding="utf-8"
    )
    return output_path


def import_state_json(path: Union[str, Path]) -> BomState:
    input_path = Path(path)
    payload = json.loads(input_path.read_text(encoding="utf-8"))
    return state_from_dict(payload)


def export_state_csv(state: BomState, directory: Union[str, Path]) -> Path:
    """
    Exports:
    - parts.csv
    - relationships.csv
    - metadata.json (for root_part_id)
    """
    output_dir = Path(directory)
    output_dir.mkdir(parents=True, exist_ok=True)

    parts_path = output_dir / "parts.csv"
    with parts_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=[
                "part_id",
                "name",
                "weight_kg",
                "unit_of_measure",
                "attributes_json",
            ],
        )
        writer.writeheader()
        for part in sorted(state.parts.values(), key=lambda p: p.part_id):
            writer.writerow(
                {
                    "part_id": part.part_id,
                    "name": part.name,
                    "weight_kg": part.weight_kg,
                    "unit_of_measure": part.unit_of_measure,
                    "attributes_json": json.dumps(part.attributes, sort_keys=True),
                }
            )

    relationships_path = output_dir / "relationships.csv"
    with relationships_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(
            fh, fieldnames=["parent_part_id", "child_part_id", "quantity"]
        )
        writer.writeheader()
        for rel in sorted(
            state.relationships,
            key=lambda r: (r.parent_part_id, r.child_part_id, r.quantity),
        ):
            writer.writerow(
                {
                    "parent_part_id": rel.parent_part_id,
                    "child_part_id": rel.child_part_id,
                    "quantity": rel.quantity,
                }
            )

    metadata_path = output_dir / "metadata.json"
    metadata_path.write_text(
        json.dumps({"root_part_id": state.root_part_id}, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return output_dir


def import_state_csv(directory: Union[str, Path]) -> BomState:
    input_dir = Path(directory)
    parts_path = input_dir / "parts.csv"
    relationships_path = input_dir / "relationships.csv"
    metadata_path = input_dir / "metadata.json"

    parts = {}
    with parts_path.open("r", newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            part = Part(
                part_id=row["part_id"],
                name=row["name"],
                weight_kg=float(row["weight_kg"]),
                unit_of_measure=row.get("unit_of_measure") or "ea",
                attributes=json.loads(row.get("attributes_json") or "{}"),
            )
            parts[part.part_id] = part

    relationships = []
    with relationships_path.open("r", newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            relationships.append(
                BomRelationship(
                    parent_part_id=row["parent_part_id"],
                    child_part_id=row["child_part_id"],
                    quantity=float(row["quantity"]),
                )
            )

    root_part_id = None
    if metadata_path.exists():
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        root_part_id = metadata.get("root_part_id")

    return BomState(parts=parts, relationships=relationships, root_part_id=root_part_id)
