from dataclasses import dataclass, field
from typing import Any


@dataclass
class Part:
    """Pure part data; no behaviors."""

    part_id: str
    name: str
    weight_kg: float = 0.0
    unit_of_measure: str = "ea"
    attributes: dict[str, Any] = field(default_factory=dict)
