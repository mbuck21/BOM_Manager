from dataclasses import dataclass


@dataclass(frozen=True)
class BomSnapshot:
    """Stable serialized BOM + hash for long-term comparison."""

    schema_version: int
    content_hash: str
    payload_json: str
