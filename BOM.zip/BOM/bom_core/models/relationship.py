from dataclasses import dataclass


@dataclass(frozen=True)
class BomRelationship:
    """Parent-child link plus quantity in the parent BOM."""

    parent_part_id: str
    child_part_id: str
    quantity: float
