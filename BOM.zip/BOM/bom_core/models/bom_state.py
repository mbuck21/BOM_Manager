from dataclasses import dataclass, field
from typing import Optional

from .part import Part
from .relationship import BomRelationship


@dataclass
class BomState:
    """
    Complete BOM data set.
    Data only; operations are defined in services.
    """

    parts: dict[str, Part] = field(default_factory=dict)
    relationships: list[BomRelationship] = field(default_factory=list)
    root_part_id: Optional[str] = None
