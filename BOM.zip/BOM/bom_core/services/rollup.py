from collections import defaultdict

from bom_core.models.bom_state import BomState


class WeightRollupService:
    """Weight rollups for multi-level BOM trees/graphs."""

    def __init__(self, state: BomState):
        self.state = state
        self._children_by_parent = defaultdict(list)
        for rel in state.relationships:
            self._children_by_parent[rel.parent_part_id].append((rel.child_part_id, rel.quantity))

    def total_weight_kg(self, part_id: str) -> float:
        """Returns own weight + all descendants with quantities."""
        visited: set[str] = set()
        return self._total_weight_kg(part_id, visited)

    def _total_weight_kg(self, part_id: str, visited: set[str]) -> float:
        if part_id in visited:
            cycle = " -> ".join(list(visited) + [part_id])
            raise ValueError(f"Cycle detected in BOM relationships: {cycle}")

        try:
            part = self.state.parts[part_id]
        except KeyError as exc:
            raise ValueError(f"Unknown part_id: {part_id}") from exc

        visited.add(part_id)
        total = part.weight_kg
        for child_part_id, qty in self._children_by_parent.get(part_id, []):
            total += qty * self._total_weight_kg(child_part_id, visited)
        visited.remove(part_id)
        return total
