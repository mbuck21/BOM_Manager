from dataclasses import replace
from typing import Optional

from bom_core.models.bom_state import BomState
from bom_core.models.part import Part
from bom_core.models.relationship import BomRelationship


class BomEditor:
    """All BOM mutation operations are centralized here."""

    def __init__(self, state: Optional[BomState] = None):
        self.state = state or BomState()

    def add_part(self, part: Part) -> None:
        if part.part_id in self.state.parts:
            raise ValueError(f"Part already exists: {part.part_id}")
        self.state.parts[part.part_id] = part
        if self.state.root_part_id is None:
            self.state.root_part_id = part.part_id

    def update_part(self, part_id: str, **changes) -> None:
        part = self._require_part(part_id)
        self.state.parts[part_id] = replace(part, **changes)

    def remove_part(self, part_id: str) -> None:
        self._require_part(part_id)
        del self.state.parts[part_id]
        self.state.relationships = [
            rel
            for rel in self.state.relationships
            if rel.parent_part_id != part_id and rel.child_part_id != part_id
        ]
        if self.state.root_part_id == part_id:
            self.state.root_part_id = next(iter(self.state.parts), None)

    def add_relationship(self, parent_part_id: str, child_part_id: str, quantity: float) -> None:
        if quantity <= 0:
            raise ValueError("Quantity must be > 0")
        self._require_part(parent_part_id)
        self._require_part(child_part_id)

        rel = BomRelationship(parent_part_id, child_part_id, quantity)
        if rel in self.state.relationships:
            raise ValueError("Relationship already exists")
        self.state.relationships.append(rel)

    def update_relationship_quantity(
        self, parent_part_id: str, child_part_id: str, quantity: float
    ) -> None:
        if quantity <= 0:
            raise ValueError("Quantity must be > 0")

        updated = []
        found = False
        for rel in self.state.relationships:
            if rel.parent_part_id == parent_part_id and rel.child_part_id == child_part_id:
                updated.append(BomRelationship(parent_part_id, child_part_id, quantity))
                found = True
            else:
                updated.append(rel)

        if not found:
            raise ValueError("Relationship not found")
        self.state.relationships = updated

    def remove_relationship(self, parent_part_id: str, child_part_id: str) -> None:
        before = len(self.state.relationships)
        self.state.relationships = [
            rel
            for rel in self.state.relationships
            if not (
                rel.parent_part_id == parent_part_id
                and rel.child_part_id == child_part_id
            )
        ]
        if len(self.state.relationships) == before:
            raise ValueError("Relationship not found")

    def _require_part(self, part_id: str) -> Part:
        try:
            return self.state.parts[part_id]
        except KeyError as exc:
            raise ValueError(f"Unknown part_id: {part_id}") from exc
