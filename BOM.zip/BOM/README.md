# Multi-Level BOM Core Structure

This project gives you a clean base to manage multi-level BOMs with strict separation between:

- Data models (parts + relationships)
- Operations (editing + rollups)
- Persistence-friendly snapshots (canonical JSON + SHA-256 hash)
- Import/export (JSON and CSV)

## Folder layout

- `bom_core/models/`: pure data classes only
- `bom_core/services/`: operations such as add/edit/remove and weight rollups
- `bom_core/storage/`: snapshot + import/export utilities
- `examples/demo.py`: end-to-end usage example
- `tests/test_bom_core.py`: basic validation tests

## Data model

- `Part`
  - `part_id`
  - `name`
  - `weight_kg`
  - `unit_of_measure`
  - `attributes` (flexible metadata dict)
- `BomRelationship`
  - `parent_part_id`
  - `child_part_id`
  - `quantity`
- `BomState`
  - `parts` map
  - `relationships` list
  - `root_part_id`

## Why snapshot hashing is useful

`create_snapshot(state)` builds canonical JSON (stable ordering) then hashes it.
That gives you:

- Reliable version identity for each complete BOM state
- Fast equality checks using hashes
- Structured diffs with `compare_snapshots(old, new)`

## Import/export

- JSON:
  - `export_state_json(state, "path/to/bom.json")`
  - `import_state_json("path/to/bom.json")`
- CSV:
  - `export_state_csv(state, "path/to/folder")`
  - `import_state_csv("path/to/folder")`

CSV export writes:

- `parts.csv`
- `relationships.csv`
- `metadata.json` (stores `root_part_id`)

## Run example

```bash
python3 examples/demo.py
```

## Run tests

```bash
python3 -m unittest discover -s tests -p 'test_*.py'
```
