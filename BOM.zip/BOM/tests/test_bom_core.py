import unittest
from pathlib import Path
import tempfile

from bom_core import (
    BomEditor,
    Part,
    WeightRollupService,
    compare_snapshots,
    create_snapshot,
    export_state_csv,
    export_state_json,
    import_state_csv,
    import_state_json,
)


class BomCoreTests(unittest.TestCase):
    def test_rollup_and_snapshot_diff(self) -> None:
        editor = BomEditor()
        editor.add_part(Part(part_id="P1", name="Top", weight_kg=1.0))
        editor.add_part(Part(part_id="P2", name="Child", weight_kg=0.2))
        editor.add_relationship("P1", "P2", quantity=3)

        rollup = WeightRollupService(editor.state)
        self.assertAlmostEqual(rollup.total_weight_kg("P1"), 1.6)

        s1 = create_snapshot(editor.state)

        editor.update_part("P2", weight_kg=0.3)
        s2 = create_snapshot(editor.state)

        diff = compare_snapshots(s1, s2)
        self.assertTrue(diff["changed"])
        self.assertEqual(diff["changed_parts"], ["P2"])

    def test_json_and_csv_round_trip(self) -> None:
        editor = BomEditor()
        editor.add_part(Part(part_id="A1", name="Top", weight_kg=1.0))
        editor.add_part(Part(part_id="B1", name="Child", weight_kg=0.4, attributes={"grade": "A"}))
        editor.add_relationship("A1", "B1", quantity=2)

        original_snapshot = create_snapshot(editor.state)

        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            json_path = tmp_path / "bom.json"
            csv_dir = tmp_path / "bom_csv"

            export_state_json(editor.state, json_path)
            export_state_csv(editor.state, csv_dir)

            imported_json_state = import_state_json(json_path)
            imported_csv_state = import_state_csv(csv_dir)

        imported_json_snapshot = create_snapshot(imported_json_state)
        imported_csv_snapshot = create_snapshot(imported_csv_state)

        self.assertEqual(imported_json_snapshot.content_hash, original_snapshot.content_hash)
        self.assertEqual(imported_csv_snapshot.content_hash, original_snapshot.content_hash)


if __name__ == "__main__":
    unittest.main()
