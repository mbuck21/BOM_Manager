from pathlib import Path
import sys
import tempfile

sys.path.append(str(Path(__file__).resolve().parents[1]))

from bom_core import (
    BomEditor,
    Part,
    WeightRollupService,
    compare_snapshots,
    create_snapshot,
    export_state_csv,
    export_state_json,
    import_state_csv,
    import_state_json,
)


def main() -> None:
    editor = BomEditor()

    # Multi-level BOM: Bike -> Wheel Assembly -> Rim/Spoke/Nipple
    editor.add_part(Part(part_id="BIKE-001", name="Bike Assembly", weight_kg=8.5))
    editor.add_part(Part(part_id="FRAME-010", name="Frame", weight_kg=2.8))
    editor.add_part(Part(part_id="WHEEL-100", name="Wheel Assembly", weight_kg=1.1))
    editor.add_part(Part(part_id="RIM-110", name="Rim", weight_kg=0.42))
    editor.add_part(Part(part_id="SPOKE-120", name="Spoke", weight_kg=0.007))
    editor.add_part(Part(part_id="NIPPLE-130", name="Nipple", weight_kg=0.0012))
    editor.add_part(Part(part_id="SEAT-200", name="Seat", weight_kg=0.35))

    editor.add_relationship("BIKE-001", "FRAME-010", quantity=1)
    editor.add_relationship("BIKE-001", "WHEEL-100", quantity=2)
    editor.add_relationship("BIKE-001", "SEAT-200", quantity=1)
    editor.add_relationship("WHEEL-100", "RIM-110", quantity=1)
    editor.add_relationship("WHEEL-100", "SPOKE-120", quantity=32)
    editor.add_relationship("WHEEL-100", "NIPPLE-130", quantity=32)

    rollup = WeightRollupService(editor.state)
    total = rollup.total_weight_kg("BIKE-001")
    print(f"Total rolled-up weight for BIKE-001: {total:.3f} kg")

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        json_path = tmp_path / "bike_bom.json"
        csv_dir = tmp_path / "bike_bom_csv"

        export_state_json(editor.state, json_path)
        export_state_csv(editor.state, csv_dir)
        print(f"Exported JSON: {json_path}")
        print(f"Exported CSV dir: {csv_dir}")

        imported_json_state = import_state_json(json_path)
        imported_csv_state = import_state_csv(csv_dir)

        original_snapshot = create_snapshot(editor.state)
        imported_json_snapshot = create_snapshot(imported_json_state)
        imported_csv_snapshot = create_snapshot(imported_csv_state)
        print("JSON import matches original:", imported_json_snapshot.content_hash == original_snapshot.content_hash)
        print("CSV import matches original:", imported_csv_snapshot.content_hash == original_snapshot.content_hash)

    # Change data and compare future revision
    editor.update_part("SPOKE-120", weight_kg=0.0085)
    editor.update_relationship_quantity("WHEEL-100", "SPOKE-120", quantity=36)

    revised_snapshot = create_snapshot(editor.state)
    diff = compare_snapshots(original_snapshot, revised_snapshot)
    print(f"Snapshot hash (original): {original_snapshot.content_hash}")
    print(f"Snapshot hash (revised): {revised_snapshot.content_hash}")
    print("Changed:", diff["changed"])
    print("Changed parts:", diff["changed_parts"])
    print("Changed relationships:", diff["changed_relationships"])


if __name__ == "__main__":
    main()
